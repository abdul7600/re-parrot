
function checkAnswers() {
    const answer = document.querySelector('input[name="q1"]:checked');
    const result = document.getElementById('result');
    if (answer && answer.value === "blue") {
        result.textContent = "Correct!";
    } else {
        result.textContent = "Try again.";
    }
}
